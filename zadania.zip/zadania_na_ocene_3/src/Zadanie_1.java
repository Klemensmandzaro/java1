public class Zadanie_1 {
    public static void zrob_zadanie(){
        Pies Burek = new Pies("Burek");
        Kot Filemon = new Kot("Filemon");
        Ryba Nema = new Ryba("Nemo");
        Animal[] zwierzata = {Burek,Filemon,Nema};
        for (int i = 0; i < 3; i++) {
            zwierzata[i].makeSound();
        }
    }
}
