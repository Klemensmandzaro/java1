public class Pies extends Animal{
    private String Imie;

    public Pies(String imie) {
        Imie = imie;
    }

    @Override
    protected void makeSound() {
        System.out.println("Hau");
    }
}
