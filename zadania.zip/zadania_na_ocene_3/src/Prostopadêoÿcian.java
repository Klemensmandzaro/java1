public class Prostopadłościan extends Figura3D{
    protected Prostopadłościan(int a, int b, int c) throws Podano_zero {
        super(new int[]{a,a,a,a,b,b,b,b,c,c,c,c});
    }

    @Override
    protected double pole() {
        double pole;
        pole=((krawedzie[1]*krawedzie[5])*2)+((krawedzie[1]*krawedzie[9])*2)+((krawedzie[5]*krawedzie[9])*2);
        return pole;
    }

    @Override
    protected int sumakr() {
        int suma=0;
        for (int i = 0; i < 12; i++) {
            suma+=krawedzie[i];
        }
        return suma;
    }

    @Override
    protected double objetosc() {
        double objetosc;
        objetosc=krawedzie[1]*krawedzie[5]*krawedzie[9];
        return objetosc;
    }
}
