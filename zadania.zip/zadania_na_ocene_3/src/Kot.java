public class Kot extends Animal{
    private String Imie;

    public Kot(String imie) {
        Imie = imie;
    }

    @Override
    protected void makeSound() {
        System.out.println("Miau");
    }
}
