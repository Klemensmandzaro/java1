public abstract class Figura {
    protected int[] krawedzie;

    protected Figura(int[] krawedzie) throws Podano_zero {
        for (int i = 0; i < (krawedzie.length); i++) {
            if (krawedzie[i]==0)
            {
                throw new Podano_zero ("Krawedź nie moze byc rowna zero");
            }
        }
        this.krawedzie = krawedzie;
    }

    protected abstract double pole();
    protected abstract int sumakr();
}
