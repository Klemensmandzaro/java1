import java.util.Scanner;

public class Zadanie_2 {
    public static void zrob_zadanie(){
        Scanner cos = new Scanner(System.in);
        try {
            int x = cos.nextInt();
            Kwadrat kwadrat = new Kwadrat(x);
            Prostokąt prostokąt = new Prostokąt(2, 4);
            Prostopadłościan prostopadłościan = new Prostopadłościan(2, 4, 6);
            Sześcian sześcian = new Sześcian(6);
            System.out.println(kwadrat.pole());
            System.out.println(kwadrat.sumakr());
            System.out.println(prostokąt.pole());
            System.out.println(prostokąt.sumakr());
            System.out.println(prostopadłościan.pole());
            System.out.println(prostopadłościan.sumakr());
            System.out.println(prostopadłościan.objetosc());
            System.out.println(sześcian.pole());
            System.out.println(sześcian.sumakr());
            System.out.println(sześcian.objetosc());
        } catch (Podano_zero e)
        {
            System.out.println(e.getMessage());
            return;
        }

    }
}
