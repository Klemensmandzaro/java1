public abstract class Figura3D extends Figura{
    protected Figura3D(int[] krawedzie) throws Podano_zero {
        super(krawedzie);
    }

    @Override
    protected abstract double pole();

    @Override
    protected abstract int sumakr();

    protected abstract double objetosc();
}
