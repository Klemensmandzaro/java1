public class Kwadrat extends Prostokąt{
    protected Kwadrat(int x) throws Podano_zero {
        super(x, x);
    }


}
