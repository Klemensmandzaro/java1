public class Ryba extends Animal{
    private String Imie;

    public Ryba(String imie) {
        Imie = imie;
    }

    @Override
    protected void makeSound() {
        System.out.println("Splash");
    }
}
