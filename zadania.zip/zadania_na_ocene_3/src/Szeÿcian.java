public class Sześcian extends Prostopadłościan{
    protected Sześcian(int a) throws Podano_zero {
        super(a, a, a);
    }
}
