public class PustyString extends Exception{
    public PustyString(String message)
    {
        super(message);
    }
}
