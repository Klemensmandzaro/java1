public class StringUtils {
    public static void odwroc(String tak) throws TakiSam, PustyString {
        String tak1= new StringBuilder(tak).reverse().toString();
        if (tak1==tak)
        {
            throw new TakiSam("Ten sam");
        } else if (tak=="") {
            throw new PustyString("Puste");
        }
        System.out.println(tak1);
    }

    public static void cezar(String tak) throws TakiSam, PustyString {
        char[] ten=tak.toCharArray();
        for (int i = 0; i < ten.length; i++) {
            ten[i]+=3;
        }
        String tak1= new String(ten);
        if (tak1==tak)
        {
            throw new TakiSam("Ten sam");
        } else if (tak=="") {
            throw new PustyString("Puste");
        }
        System.out.println(tak1);
    }

    public static void namale(String tak)
    {
        String tak1;
        tak1=tak.toLowerCase();
        if (tak1==tak)
        {
            throw new TakiSam("Ten sam");
        } else if (tak=="") {
            throw new PustyString("Puste")
        }
        System.out.println((tak.toLowerCase()));
    }

    public static void naduze(String tak)
    {
        String tak1;
        tak1=tak.toUpperCase();

        if (tak1==tak)
        {
            throw new TakiSam("Ten sam");
        } else if (tak=="") {
            throw new PustyString("Puste")
        }
        System.out.println((tak.toUpperCase()));
    }
}
