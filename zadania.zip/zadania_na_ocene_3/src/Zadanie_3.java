import java.util.Scanner;

public class Zadanie_3 {
    public static void zrob_zadanie() throws TakiSam, PustyString {
        Scanner cos = new Scanner(System.in);

        System.out.println("1. odwracanie stringów" );
        System.out.println("2. szyfrowanie stringów za pomocą szyfru Cezara");
        System.out.println("3. zamiana stringa na małe litery");
        System.out.println("4. zamiana stringa na duże litery");
        int x= cos.nextInt();

        String moj= cos.next();
    try {
        try {
            switch (x) {
                case 1:
                    StringUtils.odwroc(moj);
                    break;
                case 2:
                    StringUtils.cezar(moj);
                    break;
                case 3:
                    StringUtils.namale(moj);
                    break;
                case 4:
                    StringUtils.naduze(moj);
                    break;
            }
        } catch (TakiSam e)
        {
            System.out.println(e.getMessage());
        }
    } catch (PustyString e)
    {
        System.out.println(e.getMessage());
    }
    }
}
