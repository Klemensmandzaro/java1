public abstract class Figura2D extends Figura{
    protected Figura2D(int[] krawedzie) throws Podano_zero {
        super(krawedzie);
    }

    @Override
    protected abstract double pole();

    @Override
    protected abstract int sumakr();
}
