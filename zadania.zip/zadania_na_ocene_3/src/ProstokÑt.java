public class Prostokąt extends Figura2D{
    protected Prostokąt(int a, int b) throws Podano_zero {
        super(new int[]{a,a,b,b});
    }

    @Override
    protected double pole() {
        double pole;
        pole=krawedzie[0]*krawedzie[3];
        return pole;
    }

    @Override
    protected int sumakr() {
        int suma=0;
        for (int i = 0; i < 4; i++) {
            suma+=krawedzie[i];
        }
        return suma;
    }
}
