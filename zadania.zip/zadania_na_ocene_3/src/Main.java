public class Main {
    public static void main(String[] args) throws TakiSam, PustyString {
        //Zadanie_1.zrob_zadanie();
        //Zadanie_2.zrob_zadanie();
        Zadanie_3.zrob_zadanie();
    }
}