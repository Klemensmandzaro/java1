public class Podano_zero extends Exception{
    protected Podano_zero(String message)
    {
        super(message);
    }
}
