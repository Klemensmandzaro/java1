public class TakiSam extends Exception{
    public TakiSam(String message)
    {
        super(message);
    }
}
